"use client";

import { createContext, useContext } from "react";

import { PatientRecord } from "@/components/patients/patient-record";
import type { ActiveVisitInfo } from "@/components/patients/record/record-banner";
import type { AppointmentView } from "@/lib/appointments-view";
import type { PatientDirectoryParams } from "@/lib/patient-directory";
import type { PatientDocumentView } from "@/lib/patient-documents-queries";
import type { PatientRecordData } from "@/lib/patient-record";
import type { WorkspaceConfig } from "@/lib/specialty-workspaces";
import type { ConsultationPreAnswer } from "@/lib/consultation-queries";
import type { PatientDirectoryRow } from "@/types/database";

export type PatientRecordPaneActions = {
  onEdit: () => void;
  /** Opens the merge-duplicate modal for the open record. */
  onMergeDuplicate: () => void;
  /**
   * Whether this member may merge duplicate records (`canMergePatients`) — the
   * same predicate the server action and the 0041 RPC enforce, so the merge
   * control never renders for a role whose action would fail closed.
   */
  canMerge: boolean;
};

const NO_ACTIONS: PatientRecordPaneActions = {
  onEdit: () => {},
  onMergeDuplicate: () => {},
  canMerge: false,
};

export const PatientRecordPaneActionsContext =
  createContext<PatientRecordPaneActions>(NO_ACTIONS);

export function PatientRecordPane({
  clinicId,
  clinic,
  patient,
  record,
  documents,
  params,
  upcoming,
  past,
  timezone,
  canManage,
  aiSummaryEnabled,
  activeVisitInfo,
  backHref,
  workspace,
  preAnswers,
}: {
  /** The signed-in clinic — the prescription workspace's templates and print header. */
  clinicId: string;
  clinic: { name: string; address: string | null; phone: string | null };
  patient: PatientDirectoryRow;
  record: PatientRecordData;
  documents: PatientDocumentView[];
  params: PatientDirectoryParams;
  upcoming: AppointmentView[];
  past: AppointmentView[];
  timezone: string;
  canManage: boolean;
  aiSummaryEnabled: boolean;
  activeVisitInfo: {
    activeVisit: ActiveVisitInfo | null;
    canStart: boolean;
  };
  backHref: string;
  /** The workspace derived from the doctor's specialty — drives tabs and write CTA. */
  workspace: WorkspaceConfig;
  /** Pre-consultation answers for the active visit's booking, if any. */
  preAnswers: ConsultationPreAnswer[];
}) {
  const actions = useContext(PatientRecordPaneActionsContext);

  return (
    <PatientRecord
      key={patient.id}
      clinicId={clinicId}
      clinic={clinic}
      patient={patient}
      record={record}
      documents={documents}
      params={params}
      upcoming={upcoming}
      past={past}
      timezone={timezone}
      canManage={canManage}
      aiSummaryEnabled={aiSummaryEnabled}
      activeVisitInfo={activeVisitInfo}
      backHref={backHref}
      canMerge={actions.canMerge}
      onMergeDuplicate={actions.onMergeDuplicate}
      onEdit={actions.onEdit}
      workspace={workspace}
      preAnswers={preAnswers}
    />
  );
}
