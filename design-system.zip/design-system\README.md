﻿# MedBook AI / ClinicFlow - Design System Bundle

This archive contains all design system specifications, color tokens, component definitions, and UI/UX guidelines for MedBook AI / ClinicFlow.

## Directory Structure

### 1. core-specs/
- design-system.json: Complete design system profile (tokens, color palette, typography, shadows, borders, states, modals, badges, cards, data display).
- design-system-guide.md: Comprehensive 1,170+ line design system documentation covering visual principles, color systems, typography scale, component standards, and layout guidelines.
- BRAND_COLORS.json: Official brand hex color tokens.
- components.json: shadcn UI configuration (aliases, tailwind integration, icons, styling).
- 	ailwind.config.ts: Tailwind CSS theme configuration (custom colors, fonts, borderRadius, keyframe animations).
- globals.css: Root CSS custom properties, HSL color tokens for light and dark themes.

### 2. ui-ux-guidelines/
- Dashboard redesign specifications (two-row headers, appointment queues, widgets, sidebars).
- Website Builder UI/UX redesign and audit plans.
- Patient workspace and clinical EHR UI specifications.
- Landing page visual specifications.

### 3. rules-and-references/
- Professional UI/UX rules, guidelines, and best practices.
