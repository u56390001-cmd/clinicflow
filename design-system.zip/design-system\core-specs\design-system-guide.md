# MedBook AI — Design System

> **Project:** Doctor AI Agents + Website Builder SaaS  
> **Design System:** MedBook AI  
> **Primary UI:** Healthcare SaaS Dashboard, AI Agent, Clinic Website Builder  
> **Implementation:** Next.js + Tailwind CSS + Radix/shadcn-style UI

---

## 1. Design Philosophy

MedBook AI uses a clean, professional medical SaaS visual language.

The interface should communicate:

- Trust
- Professionalism
- Calmness
- Clarity
- Simplicity
- Modern healthcare technology

The design should avoid excessive decoration. Prioritize clear information hierarchy, generous whitespace, predictable interaction patterns, and accessible contrast.

### Core visual principle

**Clean healthcare dashboard + modern SaaS usability + friendly AI experience.**

---

# 2. Color System

## 2.1 Brand Colors

| Token | Value | Usage |
|---|---|---|
| `primary-teal` | `#0D9488` | Primary actions, branding, active navigation, AI accents |
| `secondary-slate` | `#0F172A` | Primary headings, sidebar text, high-emphasis UI |

### Primary Teal

`#0D9488`

Use for:

- Primary CTAs
- Active sidebar icons
- Active navigation states
- Important links
- Focus states
- AI agent accents
- Modal headers where appropriate
- Selected controls

Do not use teal for large decorative surfaces unless explicitly required.

---

## 2.2 Application Surfaces

| Token | Value | Usage |
|---|---|---|
| `bg-app` | `#F9FAFB` | Main dashboard background |
| `bg-surface` | `#FFFFFF` | Cards, modals, panels, inputs |
| `bg-skeleton` | `#F1F5F9` | Loading skeletons |

The dashboard canvas should remain light and neutral so teal actions and status indicators remain visually prominent.

---

## 2.3 Text Colors

| Token | Value | Usage |
|---|---|---|
| `text-primary` | `#111827` | Main content text |
| `text-secondary` | `#4B5563` | Descriptions, supporting text |
| `text-muted` | `#9CA3AF` | Placeholders, captions, secondary labels |
| `text-heading` | `#0F172A` | H1/H2/high-emphasis headings |

---

## 2.4 Status Colors

| Token | Value | Usage |
|---|---|---|
| `status-success` | `#22C55E` | Confirmed, completed, active |
| `status-destructive` | `#EF4444` | Cancelled, errors, destructive actions |
| `status-warning` | `#F59E0B` | No-show, warnings, pending attention |
| `status-info` | `#0EA5E9` | Booked, informational states |

### Status mapping

- **Confirmed:** Green
- **Cancelled:** Red
- **No-Show:** Amber
- **Booked/Info:** Sky
- **Active:** Teal where a neutral brand status is more appropriate

Status should never be communicated by color alone. Include text, icons, or labels where necessary.

---

# 3. Typography

## 3.1 Font

Primary font:

**Inter**

Fallback:

```text
Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif
```

The interface should use a consistent sans-serif system across dashboard, website builder, AI widget, onboarding, and billing.

---

## 3.2 Font Weights

| Weight | Value | Usage |
|---|---:|---|
| Regular | 400 | Body |
| Medium | 500 | Labels, captions, controls |
| Semi-bold | 600 | Section titles, card titles |
| Bold | 700 | Page titles, important metrics |

---

## 3.3 Type Scale

| Style | Size | Weight | Usage |
|---|---:|---:|---|
| H1 | `30px` / `1.875rem` | 700 | Dashboard/page header |
| H2 | `24px` / `1.5rem` | 600 | Section titles |
| H3 | `18px` / `1.125rem` | 600 | Card titles |
| Body | `14px` / `0.875rem` | 400 | Default content |
| Small | `12px` / `0.75rem` | 500 | Labels/captions |

### Typography rules

- Use `text-primary`/`text-heading` for important information.
- Use `text-secondary` for supporting descriptions.
- Use `text-muted` sparingly.
- Avoid overly small text for essential information.
- Maintain clear heading hierarchy.

---

# 4. Spacing System

## 4.1 Base Unit

All spacing is based on:

**`4px`**

Use multiples of the base unit wherever practical.

```text
4px
8px
12px
16px
20px
24px
32px
40px
48px
64px
```

---

## 4.2 Standard Padding

### Card / Modal

`16px` (`p-4`)

### Page-level

`24px` (`p-6`)

### Sidebar

Use `24px` (`p-6`) as the standard outer spacing.

---

## 4.3 Gaps

| Token | Value | Usage |
|---|---:|---|
| `gap-2` | 8px | Tight control spacing |
| `gap-3` | 12px | Form/control groups |
| `gap-4` | 16px | Cards/list items |
| `gap-6` | 24px | Major sections |
| `gap-8` | 32px | Large layout separation |

---

# 5. Layout System

## 5.1 Dashboard Grid

Use a **12-column responsive grid** for the main dashboard.

Typical structure:

```text
┌───────────────┬──────────────────────────────────────┐
│               │                                      │
│   Sidebar     │             Main Content              │
│    256px      │                                      │
│               │   Header                              │
│               │                                      │
│               │   KPI Cards                           │
│               │                                      │
│               │   Schedule / Calendar                 │
│               │                                      │
└───────────────┴──────────────────────────────────────┘
```

---

## 5.2 Sidebar

Desktop width:

**`256px`**

Characteristics:

- Permanent left-aligned navigation
- Clean visual hierarchy
- Teal active state
- Comfortable spacing
- Clear icons
- Accessible labels

Navigation should prioritize:

1. Dashboard
2. Appointments
3. Calendar
4. Patients
5. Services
6. AI Agent
7. Website
8. Billing
9. Settings

---

## 5.3 Content Hierarchy

Dashboard information should follow this hierarchy:

```text
Page Header
    ↓
Top-level KPI cards
    ↓
Primary actionable information
    ↓
Secondary information
```

For the main dashboard:

- Today's appointments and important KPIs appear first.
- Today's schedule/calendar is the primary operational area.
- Secondary metrics and supporting information appear below.

---

# 6. Border Radius

| Token | Value | Usage |
|---|---:|---|
| `radius-card` | `12px` | Cards, containers, major panels |
| `radius-button` | `8px` | Buttons |
| `radius-input` | `8px` | Inputs/selects |
| `radius-badge` | `9999px` | Status badges |
| `radius-avatar` | `9999px` | Avatars |

### Tailwind mapping

```text
rounded-xl → 12px
rounded-lg → 8px
rounded-full → 9999px
```

---

# 7. Elevation & Shadows

Primary UI elevation:

```text
shadow-sm
```

Equivalent:

```css
0 1px 2px 0 rgb(0 0 0 / 0.05)
```

Use subtle elevation.

Cards should feel separated from the application background without appearing heavy.

### Interactive elevation

On hover, interactive cards may use a slightly deeper shadow.

Do not use large, dramatic shadows for normal dashboard components.

---

# 8. Buttons

## 8.1 Primary Button

```text
Background: #0D9488
Text: #FFFFFF
Radius: 8px
```

Use for:

- Create appointment
- Save
- Publish
- Start AI
- Upgrade
- Primary onboarding actions

### Hover

Darken the button by approximately 10%.

### Disabled

Use reduced contrast and prevent interaction.

### Loading

Show a loading indicator while preserving the button's width.

---

## 8.2 Secondary / Outline

```text
Background: #FFFFFF
Border: #E2E8F0
Text: #334155
Radius: 8px
```

Use for:

- Cancel
- Back
- Secondary actions
- Filters
- Alternative actions

---

## 8.3 Destructive

```text
Background: #EF4444
Text: #FFFFFF
Radius: 8px
```

Use for:

- Delete
- Permanently cancel
- Destructive confirmation

Destructive actions should normally require confirmation.

---

## 8.4 Ghost

Use for low-emphasis actions.

- Transparent background
- No visible border
- Strong hover feedback
- Preserve accessible text contrast

---

# 9. Inputs & Forms

## Input

```text
Height: 40px
Radius: 8px
Background: #FFFFFF
Border: #E2E8F0
```

Tailwind-style:

```text
h-10 rounded-lg border border-slate-200 bg-white
```

The source specification describes `rounded-md`; however, the consolidated design token for the final system is `radius-button = 8px`, so inputs should use the same 8px control radius.

---

## Focus State

Focused controls should use:

```text
Border: #0D9488
Focus ring: Teal
```

Focus states must remain clearly visible for keyboard users.

---

## Form Labels

Use:

- 12–14px
- Medium weight
- `text-primary` or `text-secondary`

Do not rely on placeholder text as the only field label.

---

## Validation

Error state:

```text
Border: #EF4444
Text: #EF4444
```

Display a short, actionable message beneath the field.

---

# 10. Cards & Containers

Default card:

```text
Background: #FFFFFF
Radius: 12px
Shadow: shadow-sm
```

Recommended padding:

```text
16px
```

For larger sections:

```text
24px
```

Cards should have clear internal hierarchy:

```text
Card Title
Supporting text
Primary content
Optional action
```

---

# 11. KPI / Stat Cards

Dashboard KPI cards should follow:

```text
┌─────────────────────────────┐
│ Label                 Icon  │
│                             │
│ 128                         │
│ Appointments                │
│                             │
│ +12% from last week         │
└─────────────────────────────┘
```

Characteristics:

- White surface
- `rounded-xl`
- `shadow-sm`
- Large numeric value
- Small supporting label
- Icon in upper-right
- Optional trend indicator

Primary dashboard KPIs:

- Today's Appointments
- Upcoming Appointments
- Total Patients
- Cancellation Rate

---

# 12. Badges & Status Indicators

Badges:

```text
rounded-full
```

Use concise labels.

Examples:

```text
Confirmed
Cancelled
No-Show
Booked
Active
Pending
```

Recommended semantic mapping:

```text
Confirmed → Green
Cancelled → Red
No-Show → Amber
Booked → Sky
Active → Teal
```

Use icon + text when status comprehension is important.

---

# 13. Tables & Lists

Tables should be:

- Left-aligned for textual data
- Easy to scan
- Compact but not cramped
- Responsive
- Accessible

Recommended:

```text
Header
────────────────────────────────
Row
────────────────────────────────
Row
────────────────────────────────
Row
```

Use subtle separators rather than heavy borders.

Important actions should remain visible.

---

# 14. Calendar Design

The calendar is an operational interface and should prioritize:

- Date visibility
- Appointment status
- Time
- Patient name
- Service
- Quick actions

Required views:

- Month
- Week
- Day

Appointment statuses should use the established status colors.

Drag-and-drop interactions must have clear visual feedback.

---

# 15. Sidebar Navigation States

## Default

Neutral text/icons.

## Hover

Use a subtle light-teal background.

## Active

Use:

- Teal icon
- Teal text
- Light teal background

The active state must be visually obvious without overwhelming the sidebar.

---

# 16. Modal / Dialog Design

Modals should:

- Use white surface
- Use `rounded-xl`
- Use `shadow-sm` or stronger modal elevation where necessary
- Include clear title
- Include concise description
- Have obvious close control
- Use backdrop dimming
- Preserve keyboard focus

Structure:

```text
┌─────────────────────────────────┐
│ Modal Title                 ×   │
│ Description                     │
│                                 │
│ Content                         │
│                                 │
│              Cancel   Save      │
└─────────────────────────────────┘
```

---

# 17. Empty States

Empty states should be centered when appropriate.

Example:

```text
No appointments yet

Appointments created manually,
through your website, or through the AI
agent will appear here.

[Create Appointment]
```

Use:

- Simple icon/illustration
- Clear heading
- Short explanation
- One primary CTA

Avoid unnecessary decorative complexity.

---

# 18. Loading & Skeleton States

Use skeleton loading during data fetching.

Skeleton color:

```text
#F1F5F9
```

Use a pulse animation.

Skeletons should approximate the shape and size of the final content to reduce layout shift.

Examples:

- KPI skeleton
- Table row skeleton
- Card skeleton
- Calendar event skeleton
- Patient profile skeleton

---

# 19. AI Agent UI

The AI Agent should feel consistent with the dashboard but slightly more conversational.

## Widget

Recommended structure:

```text
┌──────────────────────────────┐
│ MedBook AI              ×    │
├──────────────────────────────┤
│                              │
│ AI: Hi! How can I help?      │
│                              │
│ User: I need an appointment  │
│                              │
│ AI: What service do you need?│
│                              │
├──────────────────────────────┤
│ Type your message...      ↑  │
└──────────────────────────────┘
```

## AI visual language

- Teal brand accents
- White chat surface
- Subtle borders
- Rounded message bubbles
- Clear typing/loading state
- Appointment slots presented as selectable cards/buttons

---

# 20. Website Builder UI

The website builder should use an editor + preview model.

```text
┌──────────────────┬───────────────────────────────┐
│ Editor Sidebar   │                               │
│                  │         Live Preview           │
│ Hero             │                               │
│ About            │                               │
│ Services         │                               │
│ Gallery          │                               │
│ Contact          │                               │
│ Theme            │                               │
└──────────────────┴───────────────────────────────┘
```

Editor controls should use the same:

- Typography
- Buttons
- Inputs
- Radius
- Spacing
- Status/feedback system

The public clinic website may introduce more expressive imagery, but the editor UI must remain consistent with the SaaS dashboard.

---

# 21. Onboarding

Onboarding should be:

- Simple
- Progressive
- Low cognitive load
- Centered where appropriate

Suggested flow:

```text
Create Account
    ↓
Clinic Details
    ↓
Clinic URL
    ↓
Services
    ↓
Availability
    ↓
AI Agent
    ↓
Website
    ↓
Publish
```

Use a clear progress indicator.

---

# 22. Responsive Behavior

## Desktop

- 256px sidebar
- 12-column content grid
- Multi-column KPI cards
- Full calendar

## Tablet

- Collapsible sidebar
- Reduced grid columns
- Responsive cards

## Mobile

- Navigation drawer or mobile navigation
- Single-column cards
- Full-width forms
- Touch-friendly controls
- Mobile-friendly calendar
- AI widget optimized for small screens

Do not simply shrink desktop layouts. Reflow content according to priority.

---

# 23. Accessibility

All components must support:

- Keyboard navigation
- Visible focus states
- Semantic HTML
- Accessible labels
- Appropriate ARIA attributes
- Sufficient contrast
- Screen-reader-friendly feedback
- Non-color-only status communication

Interactive controls must have usable touch targets on mobile.

---

# 24. Iconography

Use **Lucide React**.

Icons should be:

- Simple
- Consistent
- Stroke-based
- Appropriate to healthcare/SaaS context

Avoid mixing unrelated icon libraries.

Examples:

```text
Calendar
Users
Clock
Stethoscope
Bot
Globe
Settings
CreditCard
Check
X
AlertTriangle
```

---

# 25. Design Token Reference

```text
COLOR
primary-teal       #0D9488
secondary-slate    #0F172A
bg-app             #F9FAFB
bg-surface         #FFFFFF
bg-skeleton        #F1F5F9
text-primary       #111827
text-secondary     #4B5563
text-muted         #9CA3AF

STATUS
success            #22C55E
destructive        #EF4444
warning            #F59E0B
info               #0EA5E9

RADIUS
card               12px
button             8px
input              8px
badge              9999px
avatar             9999px

SPACING
base               4px
card-padding       16px
page-padding       24px
section-gap        24px

LAYOUT
sidebar            256px
grid               12 columns

SHADOW
ui                 shadow-sm
```

---

# 26. Tailwind Configuration Requirements

Implement the design system in `tailwind.config.ts` or the project's equivalent Tailwind theme configuration.

Required semantic colors:

```ts
colors: {
  primary: "#0D9488",
  secondary: "#0F172A",

  app: "#F9FAFB",
  surface: "#FFFFFF",
  skeleton: "#F1F5F9",

  text: {
    primary: "#111827",
    secondary: "#4B5563",
    muted: "#9CA3AF",
  },

  status: {
    success: "#22C55E",
    destructive: "#EF4444",
    warning: "#F59E0B",
    info: "#0EA5E9",
  },
}
```

If the existing project uses CSS variables or shadcn-style tokens instead of direct Tailwind colors, map these semantic tokens into the existing architecture rather than introducing a conflicting second system.

---

# 27. Component Library Integration

Use the existing `components/ui/` primitives as the base UI layer.

Apply the design tokens consistently to:

- Button
- Badge
- Card
- Dialog
- Dropdown
- Input
- Label
- Select
- Switch
- Tabs
- Textarea
- Tooltip
- Skeleton
- Avatar
- Progress

Do not create one-off styling for individual pages when a reusable component can express the same pattern.

---

# 28. Component Consistency Rules

The same component must look and behave consistently throughout:

- Dashboard
- Appointments
- Calendar
- Patients
- Services
- AI Settings
- Website Builder
- Billing
- Onboarding
- Account Settings

For example, the primary "Save" action must use the same button component and visual treatment everywhere.

---

# 29. Interaction Principles

### Immediate feedback

Every meaningful action should produce feedback.

Examples:

- Save → success toast
- Delete → confirmation
- Booking → confirmation state
- Failed request → error message
- Loading → skeleton/spinner

### Progressive disclosure

Do not show advanced settings until needed.

### Safe destructive actions

Require confirmation for irreversible operations.

### Preserve user context

Avoid unnecessary full-page navigation after small actions.

---

# 30. Visual QA Checklist

Before considering a page complete, verify:

- [ ] Correct color tokens
- [ ] Correct typography
- [ ] Correct spacing
- [ ] Correct border radius
- [ ] Correct shadows
- [ ] Consistent button styles
- [ ] Consistent form controls
- [ ] Responsive behavior
- [ ] Loading state
- [ ] Empty state
- [ ] Error state
- [ ] Hover state
- [ ] Focus state
- [ ] Disabled state
- [ ] Accessibility labels
- [ ] Status colors
- [ ] No unnecessary visual clutter

---

# 31. Agent-Ready Implementation Prompt

Use the following instructions when giving this design system to an AI coding agent:

> Implement the **MedBook AI Design System** across the Doctor AI Agents + Website Builder SaaS.
>
> Use **Tailwind CSS**, **Inter**, **Lucide React**, and the existing `components/ui/` Radix/shadcn-style primitives.
>
> Brand:
>
> - Primary: `#0D9488`
> - Secondary: `#0F172A`
>
> Surfaces:
>
> - Application background: `#F9FAFB`
> - Cards/inputs/modals: `#FFFFFF`
> - Skeleton: `#F1F5F9`
>
> Text:
>
> - Primary: `#111827`
> - Secondary: `#4B5563`
> - Muted: `#9CA3AF`
>
> Status:
>
> - Success: `#22C55E`
> - Destructive: `#EF4444`
> - Warning: `#F59E0B`
> - Info: `#0EA5E9`
>
> Typography:
>
> - Font: Inter
> - Base size: `14px`
> - H1: `30px / 700`
> - H2: `24px / 600`
> - H3: `18px / 600`
> - Body: `14px / 400`
> - Caption: `12px / 500`
>
> Layout:
>
> - Desktop sidebar: `256px`
> - Main dashboard: 12-column responsive grid
> - Page padding: `24px`
> - Card padding: `16px`
> - Base spacing unit: `4px`
>
> Radius:
>
> - Cards: `12px`
> - Buttons/inputs: `8px`
> - Badges/avatars: `9999px`
>
> Elevation:
>
> - Default cards: `shadow-sm`
> - Hover states may use slightly deeper elevation
>
> Component behavior:
>
> - Primary buttons use teal with white text.
> - Secondary buttons use white background and `#E2E8F0` border.
> - Destructive actions use red.
> - Inputs use 40px height and 8px radius.
> - Focus states use teal.
> - Status badges use semantic colors.
> - Skeletons use `#F1F5F9` with pulse animation.
>
> Do not introduce arbitrary colors, spacing values, typography styles, or radius values unless there is a documented product requirement.
>
> Reuse existing UI primitives instead of creating duplicate components.
>
> Apply the system consistently to the Dashboard, Appointments, Calendar, Patients, Services, AI Agent, Website Builder, Billing, Onboarding, and Settings.
>
> Preserve responsive behavior and accessibility.
>
> The visual result should feel like a **premium, trustworthy, minimal healthcare SaaS product**, not a generic admin template.

---

# 32. Final Design Direction

The MedBook AI interface should feel:

**Professional + Calm + Modern + Trustworthy + Minimal + AI-enabled**

The design system is intentionally restrained:

```text
Neutral surfaces
      +
Teal brand actions
      +
Clear typography
      +
Subtle elevation
      +
Consistent spacing
      +
Semantic status colors
      +
Strong information hierarchy
```

The goal is not to make the application visually loud.

The goal is to make doctors feel that the product is **reliable, easy to understand, and safe to operate every day**.
